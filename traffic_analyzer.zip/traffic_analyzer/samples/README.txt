Поклади сюди свій example.pcap (зроби tcpdump) або видали цю теку.
