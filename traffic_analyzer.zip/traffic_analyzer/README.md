# Traffic Analyzer

Мінімальний інструмент для аналізу мережевого трафіку: перехоплення пакетів (live) або читання з `.pcap`, базова статистика (топ IP, порти, протоколи), звіти у CSV та простий графік у Matplotlib.

## Установка
```bash
python3 -m venv .venv && source .venv/bin/activate
pip install -r requirements.txt
```

## Запуск
Live-sniff (Linux, може знадобитись `sudo` — заміни `eth0` на свій інтерфейс):
```bash
sudo python3 main.py --iface eth0 --duration 30
```

Аналіз з файлу:
```bash
python3 main.py --pcap samples/example.pcap
```

Побудова графіка (на основі `out/packets.csv`):
```bash
python3 visualize.py out/packets.csv
```

## Примітки щодо прав
Для live-sniff без sudo можна видати capability інтерпретатору Python:
```bash
sudo setcap cap_net_raw,cap_net_admin+eip $(readlink -f $(which python3))
```
